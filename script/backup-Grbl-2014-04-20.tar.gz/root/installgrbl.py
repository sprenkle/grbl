import os.path
from subprocess import call

if not os.path.isfile("/root/grblinstalled.txt"):
	call(["run-avrdude", "/root/grbl.hex"])
	f = open("/root/grblinstalled.txt", "w")
	f.write("programmed")
	f.close()	
